import homeController from '../controllers/homeController';
import search from '../controllers/search';
import basic from '../controllers/basic'
import getProfile from '../controllers/getThisProfile'
import updateProfile from '../controllers/updateProfile'

import posts from '../controllers/post/postsController';
import increaseLike from '../controllers/post/increaseLikeController';
import addPost from '../controllers/post/addpostController';
import delPost from '../controllers/post/delPostCont.js';
import getThese from '../controllers/post/getThesePosts';

import studentSignup from '../controllers/student/studentSignup';
import studentLogin from '../controllers/student/studentLogin';
import setPassword from '../controllers/student/setPasswordController';
import resetpassword from '../controllers/student/resetpassword'
import getOneStu from '../controllers/student/getOneStu';

import studentUpdate from '../controllers/studentBioUpdate'
import updateProfilePic from '../controllers/updateProfilePic'

import addConf from '../controllers/conf/addconfController'
import authConf from '../controllers/conf/authconfController'
import getConf from '../controllers/conf/confController';

import setPasswordClub from '../controllers/club/setPasswordclub'
import resetpasswordClub from '../controllers/club/resetPassclub'
import clubSignup from '../controllers/club/addClub';
import clubLogin from '../controllers/club/clubLogin';
import getOneClub from '../controllers/club/getOneClub'
import addbranchs from './../controllers/tests/addbranchs';
//import validate from './../controllers/validate';
import addAdmin from './../controllers/admin/addAdmin'
import adminLogin from '../controllers/admin/adminLogin'

export default function(app) {
    app.get('/', homeController.get);
    app.get('/basic', basic.get);
    app.get('/search/:search', search.get);
    app.get('/getprofile/:_id', getProfile.get)
    app.post('/updateprofile', updateProfile.post);

    //post routes............................................................................
    app.get('/getposts/:_id', posts.get);
    app.post('/addpost', addPost.post);
    app.get('/delpost/:_id', delPost.get);
    app.get('/likepost/:_id', increaseLike.get);
    app.post('/gettheseposts', getThese.post);

    app.post('/addBranch', addbranchs.post);
    //app.post('/validate', validate.post);

    //student routes............................................................................
    app.post('/student/register', studentSignup.post);
    app.post('/student/login', studentLogin.post);
    app.get('/student/profile/:_id',getOneStu.get)
    // app.get('/student/mydetails') //<-----------


    //conf routes.......................................................................
    app.post('/addconf', addConf.post)
    app.get('/admin/authconf/:_id', authConf.get) //<-----------
    app.get('/getconfs/:_id', getConf.get)
    app.get('/admin/getconfs/:_id', getConf.get2)


    //club routes.........................................................................
    app.post('/club/login', clubLogin.post)
    app.get('/club/profile/:_id', getOneClub.get)
    // app.get('/club/addmember:_id') //<--------------
    // app.get('/club/removemember:_id') //<------------ 


    //authanticaton routes.........................................................................
    app.get('/setpassword/student/:who', setPassword.get);
    app.post('/setpassword/student/:who', setPassword.post);
    app.get('/resetpassword/student', resetpassword.get);

    app.get('/setpassword/club/:who', setPasswordClub.get);
    app.post('/setpassword/club/:who', setPasswordClub.post);
    app.get('/resetpassword/club', resetpasswordClub.get);
    // app.post('/student/club', clubLogin.post);



    // admin routes....................................................................................
    // app.post('/admin/login') //<-------------
    // app.get('/admin/deleteStuAccount/:_id') //<---------
    // app.get('/admin/deleteClubAccount/:_id') //<---------
    // app.get('/admin/deletePost/:_id') //<---------
    // app.get('/admin/deleteConf/:_id') //<---------
    app.post('/admin/addadmin',addAdmin.post);
    app.post('/admin/login', adminLogin.post);
    
    app.post('/admin/addclub' ,clubSignup.post);


    app.post('/bioupdate', studentUpdate.post);
    app.post('/updateprofilepic', updateProfilePic.post);

    app.use(function errorHandler (err, req, res, next) {
        if (res.headersSent) {
            return next(err)
        }
        res.status(500)
        console.log(err)
        return res.json({
            msg: 'there is some problem in server. Only images are accepted',
            status: false,
            code: 500
        })
      }
    )
}