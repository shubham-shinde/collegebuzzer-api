import { Students, Clubs } from '../mongoose/mongoosConfig';
import jwt from 'jsonwebtoken';
import { SESSION_SECRET } from '../appconfig';
import { ROLES } from '../appconfig';

export default {
    post : _post
}

function _post (req, res, next) {
    console.log("got a post request to register")
    console.log(req.body)
    const bio = req.body.bio;

    if(req.session.role === ROLES[0]) {
        Students.findOne({_id: req.session.Id}).exec((err, doc) => {
            if(err)
                next(err);
            
            if(bio) {
                doc.bio = bio;
                doc.save(() => {
                    res.json({
                        msg: 'bio is saved',
                        status: true
                    })
                })
            }
            else {
                res.json({
                    msg: "bio cant be null",
                    status: false,
                })
            }
        })
    }
    else if (req.session.role === ROLES[1]) {
        Clubs.findOne({_id: req.session.id}).exec((err, doc) => {
            if(err)
                next(err);
            
            if(bio) {
                doc.bio = bio;
                doc.save(() => {
                    res.json({
                        msg: 'bio is saved and plz check the mail to set password',
                        status: true
                    })
                })
            }
            else {
                res.json({
                    msg: "bio cant be null",
                    status: false,
                })
            }
        })
    }
}