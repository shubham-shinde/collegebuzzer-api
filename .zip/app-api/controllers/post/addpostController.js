import { Posts, Students, Clubs } from '../../mongoose/mongoosConfig';
import { ROLES, AWS_S3, AWS_S3_LINK } from '../../appconfig.js'
import im from 'imagemagick'
import AWS from 'aws-sdk'
import fs from 'fs';
import resetpassword from '../student/resetpassword';

export default {
    post : _post
}

function uploadPicToS3(files, name, res, next) {
    AWS.config = AWS_S3;

    var s3Bucket = new AWS.S3( { params: {Bucket: 'photosfortheapp'} } )

    files.forEach((element, index) => {
        const NameOfPic = name+index;
        const NameOfPicPre = name+index+'pre'
        im.resize({
            srcPath: element.path,
            dstPath: element.desination+NameOfPic,
            width:   1000
        },
        function(err, stdout, stderr){
            if (err) {
                res.status(400)
                return res.json({
                    msg: 'only image are allowed',
                    status: true,
                    code: 400
                })
            }

            fs.readFile(element.desination+NameOfPic,(err, pic) => {
                const data = {Key: 'posts/'+NameOfPic+'.jpg', Body: pic};
                s3Bucket.putObject(data, function(err, data){
                if (err) 
                    { 
                        res.status(400)
                        return res.json({
                            msg: 'there is problem in server please try again.',
                            status: true,
                            code: 400
                        })
                    } 
                    else {
                        console.log('succesfully uploaded the image!');
                        fs.unlink(element.desination+NameOfPic,() => console.log('deleted'))
                        im.resize({
                            srcPath: element.path,
                            dstPath: element.desination+NameOfPicPre,
                            width:   40
                        },
                        function(err, stdout, stderr){
                            if (err) {
                                res.status(400)
                                return res.json({
                                    msg: 'there is problem in server please try again.',
                                    status: true,
                                    code: 400
                                })
                            }
                
                            fs.readFile(element.desination+NameOfPicPre,(err, pic) => {
                                const data = {Key: 'posts/'+NameOfPicPre+'.jpg', Body: pic};
                                s3Bucket.putObject(data, function(err, data){
                                if (err) 
                                    { 
                                        res.status(400)
                                        return res.json({
                                            msg: 'there is problem in server please try again.',
                                            status: true,
                                            code: 400
                                        })
                                    } 
                                    else {
                                        console.log('succesfully uploaded the image!');
                                        fs.unlink(element.desination+NameOfPicPre,() => console.log('deleted'))
                                        fs.unlink(element.path,() => console.log('deleted'))
                                        if(index+1 === files.length ) {
                                            res.status(200)
                                            return res.json({
                                                msg: 'post is saved',
                                                status: true,
                                                code: 204
                                            })
                                        }
                                    }
                                });
                            })            
                        });
                    }
                });
            })            
        });
    });
}

function _post (req, res, next) {
    const post_data = req.body;
    console.log('reqbody', req.body);
    if(req.session.role === ROLES[0]) {       
        
        Students.findOne({_id: req.session.Id}).exec((err, student) => {
            if(err){
                next(err);
            }
            if(!student) {
                res.status(401)
                return res.json({
                    msg: "your not in database",
                    status: true,
                    code: 401
                })
            }
            if(!student.p_pic) {
                student.p_pic = AWS_S3_LINK+'profile/'+student._id+'.jpg'
            }
            const new_post = Posts({
                f_name : student.f_name,
                m_name : student.m_name,
                l_name : student.l_name,
                Id : req.session.Id,
                userIntro : student.userIntro,
                text : post_data.text,
                n_pics : req.files.length,
                p_pic : student.p_pic,
                time : Date.now(),
                likes : [ req.session.Id ],
                is_auth : true
            })

            new_post.save((err, post) => {
                if(err) {
                    next(err);
                }
    
                student.h_posts  = [post._id , ...student.h_posts];

                student.save((err) => {
                    if(err){
                        console.log(err);
                        next(err);
                    }
                    if(req.files) {
                        uploadPicToS3(req.files, post._id, res, next)
                    }
                    else {
                        res.status(200)
                        return res.json({
                            msg: 'post is saved',
                            status: true,
                            code: 204
                        })
                    }
                })   
            })         
        })
    }
    else if (req.session.role === ROLES[1]) {
        console.log('you are a club')
        Clubs.findOne({_id: req.session.Id}).exec((err, club) => {
            if(err){
                next(err);
            }
            if(!club) {
                res.status(401)
                return res.json({
                    msg: "your not in database",
                    status: true,
                    code: 401
                })
            }
            if(!club.p_pic) {
                club.p_pic = AWS_S3_LINK+'profile/'+club._id+'.jpg'
            }
            const new_post = Posts({
                f_name : club.f_name,
                m_name : club.m_name,
                l_name : 'Club',
                Id : req.session.Id,
                p_pic : club.p_pic,
                text : post_data.text,
                n_pics : req.files.length,
                time : Date.now(),
                likes : [],
                is_auth : true
            })

            new_post.save((err, post) => {
                if(err) {
                    next(err);
                }
    
                club.h_posts  = [post._id, ...club.h_posts];

                club.save((err) => {
                    if(err){
                        next(err);
                    }
                    uploadPicToS3(req.files, post._id,res, next)
                })   
            })         
        })
    } 
    else {
        res.status(400)
        res.json({
            msg: 'you are not allowed to add posts',
            status: false,
            code: 400
        })
    }          
}