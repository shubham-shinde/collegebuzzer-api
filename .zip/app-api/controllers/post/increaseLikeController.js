import { Posts } from '../../mongoose/mongoosConfig';

export default {
    get : _get
}

function _get (req, res, next) {
    const post_id = req.params._id;
    Posts.findOne({_id : post_id}).exec((err, post) => {
        if(err){
            return next(err);
        }
        if(post.likes.indexOf(req.session.Id) > -1) {
            res.status(406)
            return res.json({
                msg: 'you already liked this post',
                status: true,
                code: 406
            })
        }
        else {
            post.likes.push(req.session.Id)
            post.save((err) => {
                if(err) {
                    return next(err)
                }
                res.status(200)
                res.json({
                    msg: 'you liked post',
                    status: true,
                    code: 204
                })
            })
        }
    })    
}