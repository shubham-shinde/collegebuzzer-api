import { Students } from '../mongoose/mongoosConfig';
import { Clubs, Admins } from '../mongoose/mongoosConfig';
import { ROLES, AWS_S3_LINK } from '../appconfig';

export default {
    get : _get
}

function _get (req, res, next) {
    if (req.session.role === ROLES[0]) {
        Students.findOne({_id : req.session.Id }).exec((err, student) => {
            if(err) {
                next(err)
            }
            if(!student) {
                res.status(400)
                return res.json({
                    msg : 'student is not available',
                    status: true,
                    code: 400
                })
            }

            Clubs.find({}).exec((err, clubs) => {
                const NamesAndIds = clubs.map((data) => {
                    let p_pic = data.p_pic
                    if(!data.p_pic) {
                        p_pic = AWS_S3_LINK+'profile/'+data._id+'.jpg'
                    }
                    return {
                        _id: data._id,
                        f_name: data.f_name,
                        m_name: data.m_name,
                        l_name: 'Club',
                        theme: data.theme,
                        bio: data.bio,
                        p_pic
                    }
                })

                const send_stu = {
                    _id : student._id,
                    f_name : student.f_name,
                    m_name : student.m_name,
                    l_name : student.l_name,
                    theme: student.theme,
                    clubs : NamesAndIds,
                    role: req.session.role,
                    bio: student.bio,
                    p_pic : student.p_pic,
                    userIntro : student.userIntro,
                }
                res.status(200)
                res.json({
                    msg : 'data is send',
                    status: true,
                    code: 200,
                    basic: send_stu
                })
            })

            // const posts = student.h_posts.map((postf) => {
            //     const pics = createPicLink(postf.n_pics, postf._id)
            //     return {...postf, pics}
            // })

            
        })    
    }
    else if (req.session.role === ROLES[1]) {
        Clubs.findOne({_id : req.session.Id }).exec((err, student) => {
            if(err) {
                next(err)
            }
            console.log(student)
            if(!student) {
                res.status(400)
                return res.json({
                    msg : 'student is not available',
                    status: true,
                    code: 400
                })
            }

            Clubs.find({}).exec((err, clubs) => {
                const NamesAndIds = clubs.map((data) => {
                    let p_pic = data.p_pic
                    if(!data.p_pic) {
                        p_pic = AWS_S3_LINK+'profile/'+data._id+'.jpg'
                    }
                    return {
                        _id: data._id,
                        f_name: data.f_name,
                        m_name: data.m_name,
                        theme: data.theme,
                        bio: data.bio,
                        l_name: 'Club',
                        p_pic
                    }
                })

                const send_stu = {
                    _id : student._id,
                    f_name : student.f_name,
                    m_name : student.m_name,
                    l_name : student.l_name,
                    theme : student.theme,
                    bio: student.bio,
                    role : req.session.role,
                    clubs : NamesAndIds,
                    p_pic : student.p_pic,
                    userIntro : student.userIntro,
                }
                res.status(200)
                res.json({
                    msg : 'data is send',
                    status: true,
                    code: 200,
                    basic : send_stu
                })
            })

            // const posts = student.h_posts.map((postf) => {
            //     const pics = createPicLink(postf.n_pics, postf._id)
            //     return {...postf, pics}
            // })

            
        }) 
    }
    else if (req.session.role === ROLES[2]) {
        Admins.findOne({_id : req.session.Id }).exec((err, student) => {
            if(err) {
                next(err)
            }
            console.log(student)
            if(!student) {
                res.status(400)
                return res.json({
                    msg : 'student is not available',
                    status: true,
                    code: 400
                })
            }

            Clubs.find({}).exec((err, clubs) => {
                const NamesAndIds = clubs.map((data) => {
                    let p_pic = data.p_pic
                    if(!data.p_pic) {
                        p_pic = AWS_S3_LINK+'profile/'+data._id+'.jpg'
                    }
                    return {
                        _id: data._id,
                        f_name: data.f_name,
                        m_name: data.m_name,
                        theme: data.theme,
                        bio: data.bio,
                        l_name: 'Club',
                        p_pic
                    }
                })

                const send_stu = {
                    _id : student._id,
                    f_name : student.f_name,
                    m_name : student.m_name,
                    l_name : student.l_name,
                    role: req.session.role,
                    theme: student.theme,
                    clubs : NamesAndIds,
                    p_pic : student.p_pic,
                    userIntro : student.userIntro,
                }
                res.status(200)
                res.json({
                    msg : 'data is send',
                    status: true,
                    code: 200,
                    basic: send_stu
                })
            })

            // const posts = student.h_posts.map((postf) => {
            //     const pics = createPicLink(postf.n_pics, postf._id)
            //     return {...postf, pics}
            // })

            
        }) 
    }
}

function createPicLink(no, id) {
    const pics = []
    for(var i=0; i< no; i++) {
        pics.push({
            pre: AWS_S3_LINK+'posts/'+id+'pre'+'.jpg',
            pic: AWS_S3_LINK+'posts/'+id+'.jpg'
        })
    }
    return pics;
} 

function filterClubInfo(clubs) {
    const filtered = clubs.map((club) => {
        return {
            f_name : club.f_name,
            l_name : 'Club',
            p_pic : club.p_pic,
            _id : club._id            
        }
    })
}