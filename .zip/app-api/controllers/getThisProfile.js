import { Students, Clubs } from '../mongoose/mongoosConfig';

export default {
    get : _get
}

function _get (req, res, next) {
    const _id = req.params._id;
    console.log(_id)
    Students.findOne({_id}).exec((err, student) => {
        if(err) {
            next(err)
        }
        console.log(student)
        if(!student) {
            Clubs.findOne({_id}).exec((err, club) => {
                if(err) {
                    next(err)
                }
                if(!club) {
                    res.status(400)
                    return res.json({
                        msg : 'no profile with this id',
                        status: false,
                        code: 404
                    })
                }
                
        
                const send_stu = {
                    f_name : club.f_name,
                    m_name : club.m_name,
                    l_name : 'Club',
                    theme : club.theme,
                    p_pic : club.p_pic,
                    bio : club.bio,
                    h_posts : club.h_posts
                }
                res.status(200)
                res.json({
                    msg : 'this is awesome',
                    status: true,
                    code: 200,
                    profile: send_stu
                })
            })    
        }

        // const posts = student.h_posts.map((postf) => {
        //     const pics = createPicLink(postf.n_pics, postf._id)
        //     return {...postf, pics}
        // })
        else {
            const send_stu = {
                _id : student._id,
                f_name : student.f_name,
                m_name : student.m_name,
                l_name : student.l_name,
                theme : student.theme,
                p_pic : student.p_pic,
                userIntro : student.userIntro,
                bio : student.bio,
                h_posts : student.h_posts
            }
            res.status(200)
            res.json({
                msg : 'this is awesome',
                status: true,
                code: 200,
                profile: send_stu
            })
        }
        
    })    
}

function createPicLink(no, id) {
    const pics = []
    for(var i=0; i< no; i++) {
        pics.push({
            pre: AWS_S3_LINK+'posts/'+id+'pre'+'.jpg',
            pic: AWS_S3_LINK+'posts/'+id+'.jpg'
        })
    }
    return pics;
} 

function filterClubInfo(clubs) {
    const filtered = clubs.map((club) => {
        return {
            f_name : club.f_name,
            l_name : 'Club',
            p_pic : club.p_pic,
            _id : club._id            
        }
    })
}