import stuRegister from './stuRegister';
import stuLogin from './stuLogin';
import stuSetPass from './stuSetPass';
import stuResetPass from './stuResetPass'
import stuGetOne from './stuGetOne';

export default {
    stuRegister,
    stuLogin,
    stuSetPass,
    stuResetPass,
    stuGetOne
}