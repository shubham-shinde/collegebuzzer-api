import guestLogin from './guestLogin'
import guestRegister from './guestRegister'
import guestResetPass from './guestResetPass'
import guestSetPass from './guestSetPass'

export default {
    guestLogin,
    guestRegister,
    guestResetPass,
    guestSetPass
}