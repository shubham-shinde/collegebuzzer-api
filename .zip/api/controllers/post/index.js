import postStuGet from './postStuGet';
import postClubGet from './postClubGet';
import postLike from './postLike';
import postAdd from './postAdd';
import postDel from './postDel';
import postGet from './postGet';

export default {
    postStuGet,
    postClubGet,
    postLike,
    postAdd,
    postDel,
    postGet
}