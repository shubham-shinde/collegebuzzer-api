
import adminAdd from './adminAdd'
import adminLogin from './adminLogin'

export default {
    adminAdd,
    adminLogin
}