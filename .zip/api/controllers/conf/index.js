import confAdd from './confAdd'
import confAuth from './confAuth'
import confGet from './confGet';

export default {
    confAdd,
    confAuth,
    confGet
}