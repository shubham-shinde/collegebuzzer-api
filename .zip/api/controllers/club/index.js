import clubSetPass from './clubSetPass'
import clubResetPass from './clubResetPass'
import clubAdd from './clubAdd'
import clubLogin from './clubLogin'
import clubGetOne from './clubGetOne'
import clubForLogin from './clubForLogin'

export default {
    clubSetPass,
    clubResetPass,
    clubAdd,
    clubLogin,
    clubGetOne,
    clubForLogin
}